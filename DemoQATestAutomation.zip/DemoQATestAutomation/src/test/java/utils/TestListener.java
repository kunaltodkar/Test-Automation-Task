package utils;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class TestListener implements ITestListener {
    @Override
    public void onTestSuccess(ITestResult result) {
        ScreenshotUtil.captureScreenshot(((BaseTest) result.getInstance()).driver, result.getName() + "_success");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        ScreenshotUtil.captureScreenshot(((BaseTest) result.getInstance()).driver, result.getName() + "_failure");
    }

    @Override
    public void onStart(ITestContext context) { }
    @Override
    public void onFinish(ITestContext context) { }
}
