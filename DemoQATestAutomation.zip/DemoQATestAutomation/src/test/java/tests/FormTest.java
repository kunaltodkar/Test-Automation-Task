package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import utils.BaseTest;
import utils.TestListener;

@Listeners(TestListener.class)
public class FormTest extends BaseTest {

    @DataProvider(name = "formData")
    public Object[][] getData() {
        return new Object[][] {
                {"John", "Doe", "john.doe@gmail.com", "1234567890"},
                {"Alice", "Smith", "alice.smith@gmail.com", "9876543210"}
        };
    }

    // Positive Test
    @Test(dataProvider = "formData")
    public void testValidFormSubmission(String firstName, String lastName, String email, String mobile) {
        driver.findElement(By.id("firstName")).sendKeys(firstName);
        driver.findElement(By.id("lastName")).sendKeys(lastName);
        driver.findElement(By.id("userEmail")).sendKeys(email);
        driver.findElement(By.id("userNumber")).sendKeys(mobile);
        WebElement submitBtn = driver.findElement(By.id("submit"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", submitBtn);
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", submitBtn);
    }

    // Negative Test - Missing Fields
    @Test
    public void testMissingFields() {
        WebElement submitBtn = driver.findElement(By.id("submit"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", submitBtn);
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", submitBtn);
        WebElement errorField = driver.findElement(By.id("firstName"));
        Assert.assertTrue(errorField.isDisplayed());
    }

    // Negative Test - Invalid Email
    @Test
    public void testInvalidEmail() {
        driver.findElement(By.id("userEmail")).sendKeys("invalidEmail");
        WebElement submitBtn = driver.findElement(By.id("submit"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", submitBtn);
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", submitBtn);
        WebElement emailField = driver.findElement(By.id("userEmail"));
        Assert.assertTrue(emailField.isDisplayed());
    }

    // Positive Test - Multiple Hobbies
    @Test
    public void testMultipleHobbiesSelection() {
        WebElement checkbox1 = driver.findElement(By.xpath("//input [@id = 'hobbies-checkbox-1']"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", checkbox1);
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", checkbox1);
        WebElement checkbox2 = driver.findElement(By.xpath("//input [@id = 'hobbies-checkbox-2']"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", checkbox2);
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", checkbox2);
        Assert.assertTrue(driver.findElement(By.xpath("//input [@id = 'hobbies-checkbox-1']")).isSelected());
        Assert.assertTrue(driver.findElement(By.xpath("//input [@id = 'hobbies-checkbox-2']")).isSelected());
    }

    // Positive Test - File Upload
   // @Test
    public void testFileUpload() {
        WebElement upload = driver.findElement(By.id("uploadPicture"));
        upload.sendKeys(System.getProperty("user.dir") + "/src/test/resources/sample.png");
        Assert.assertTrue(upload.getAttribute("value").contains("sample.png"));
    }
}
